document.addEventListener('DOMContentLoaded', () => {
  
    const apiUrl = 'http://tuservidor.com/api/semaforos'; // Cambia esto por la URL correcta


    function obtenerDatos() {
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => mostrarDatos(data))
            .catch(error => console.error('Error al obtener los datos:', error));
    }

    function mostrarDatos(data) {
        const contenedor = document.getElementById('semaforos');
        contenedor.innerHTML = '';

        data.forEach(semaforo => {
            const div = document.createElement('div');
            div.className = `semaforo ${semaforo.estado}`;
            div.innerHTML = `
                <h3>${semaforo.ubicacion}</h3>
                <p>Estado: ${semaforo.estado}</p>
            `;
            contenedor.appendChild(div);
        });
    }

    // Llamar a la función para obtener los datos cuando se cargue la página
    obtenerDatos();
});



